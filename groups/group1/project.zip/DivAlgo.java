import java.util.Scanner;

public class DivAlgo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String dividendText = scanner.hasNextLine() ? scanner.nextLine() : "";
        String divisorText = scanner.hasNextLine() ? scanner.nextLine() : "";

        if (!hasValidInput(dividendText, divisorText)) {
            return;
        }

        int dividend = Integer.parseInt(dividendText.trim());
        int divisor = Integer.parseInt(divisorText.trim());
        int quotient = dividend / divisor;
        int remainder = dividend % divisor;

        System.out.println("Dividend: " + dividend);
        System.out.println("Divisor: " + divisor);
        System.out.println("Quotient: " + quotient);
        System.out.println("Remainder: " + remainder);
        System.out.println(dividend + " = " + divisor + "(" + quotient + ") + " + remainder);
    }

    static boolean hasValidInput(String dividendText, String divisorText) {
        if (!isInteger(dividendText)) {
            System.out.println("Invalid input. Enter an integer dividend.");
            return false;
        }

        if (!isInteger(divisorText)) {
            System.out.println("Invalid input. Enter an integer divisor.");
            return false;
        }

        if (Integer.parseInt(divisorText.trim()) == 0) {
            System.out.println("Invalid input. Divisor must be a non-zero integer.");
            return false;
        }

        return true;
    }

    static boolean isInteger(String value) {
        try {
            Integer.parseInt(value.trim());
            return true;
        } catch (NumberFormatException error) {
            return false;
        }
    }
}
