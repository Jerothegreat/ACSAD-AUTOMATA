@echo off
echo Compiling...
javac logic\*.java gui\*.java
if %errorlevel% neq 0 ( echo Compilation FAILED. & pause & exit /b 1 )
echo OK! Starting...
java gui.RecursionApp
pause
