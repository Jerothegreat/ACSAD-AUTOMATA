package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * MenuPanel — Main menu screen with 2x2 card-button grid.
 */
public class MenuPanel extends JPanel {

    public MenuPanel(CardLayout cardLayout, JPanel parent, Runnable onExit) {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG);
        add(buildHeader(),                            BorderLayout.NORTH);
        add(buildCentre(cardLayout, parent, onExit), BorderLayout.CENTER);
        add(buildFooter(),                            BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.HEADER);
        header.setBorder(BorderFactory.createEmptyBorder(18, 32, 18, 32));
        JLabel title = new JLabel("AUTOMATA \u2014 Recursion Lab Activity #4", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Finals Laboratory Group Activity", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_SUB);
        sub.setForeground(new Color(180, 200, 255));
        JPanel box = new JPanel(new GridLayout(2, 1, 0, 3));
        box.setOpaque(false);
        box.add(title); box.add(sub);
        header.add(box, BorderLayout.CENTER);
        return header;
    }

    private JPanel buildCentre(CardLayout cardLayout, JPanel parent, Runnable onExit) {
        JPanel centre = new JPanel(new BorderLayout(20, 20));
        centre.setBackground(UITheme.BG);
        centre.setBorder(BorderFactory.createEmptyBorder(24, 40, 10, 40));
        centre.add(loadScaledImage("images/image1.png", 520, 180), BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UITheme.BG);

        JPanel grid = new JPanel(new GridLayout(3, 2, 16, 16));
        grid.setBackground(UITheme.BG);
        grid.setBorder(BorderFactory.createEmptyBorder(16, 0, 16, 0));

        grid.add(makeCard("1)  Fibonacci Numbers",
            "F\u2080=0, F\u2081=1  |  F\u2099 = F\u2099\u208B\u2081 + F\u2099\u208B\u2082",
            UITheme.ACCENT_FIBO,  e -> cardLayout.show(parent, "FIBONACCI")));
        grid.add(makeCard("2)  Lucas Numbers",
            "L\u2080=2, L\u2081=1  |  L\u2099 = L\u2099\u208B\u2081 + L\u2099\u208B\u2082",
            UITheme.ACCENT_LUCAS, e -> cardLayout.show(parent, "LUCAS")));
        grid.add(makeCard("3)  Tribonacci Numbers",
            "T\u2080=0, T\u2081=0, T\u2082=1  |  T\u2099 = T\u2099\u208B\u2081 + T\u2099\u208B\u2082 + T\u2099\u208B\u2083",
            UITheme.ACCENT_TRIBO, e -> cardLayout.show(parent, "TRIBONACCI")));
        grid.add(makeCard("4)  Collatz Sequence",
            "odd: 3n+1  |  even: n/2  |  stops at 1",
            UITheme.ACCENT_COLLATZ, e -> cardLayout.show(parent, "COLLATZ")));
        grid.add(makeCard("5)  Division Algorithm",
            "m = n(q) + r, with 0 <= r < n",
            UITheme.ACCENT_DIVISION, e -> cardLayout.show(parent, "DIVISION")));
        grid.add(makeCard("6)  Euclidean Algorithm",
            "Repeated division to find GCD and LCM",
            UITheme.ACCENT_EUCLID, e -> cardLayout.show(parent, "EUCLIDEAN")));

        JButton exitBtn = new JButton("Exit Application");
        exitBtn.setFont(UITheme.FONT_BTN);
        exitBtn.setBackground(UITheme.ACCENT_EXIT);
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.setOpaque(true);
        exitBtn.setBorderPainted(false);
        exitBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        exitBtn.setBorder(BorderFactory.createEmptyBorder(8, 24, 8, 24));
        exitBtn.addActionListener(e -> onExit.run());

        JPanel exitWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        exitWrap.setBackground(UITheme.BG);
        exitWrap.add(exitBtn);

        content.add(grid);
        content.add(Box.createVerticalStrut(4));
        content.add(exitWrap);

        centre.add(content, BorderLayout.CENTER);
        return centre;
    }

    private JLabel buildFooter() {
        JLabel footer = new JLabel("Select an algorithm above to begin", SwingConstants.CENTER);
        footer.setFont(UITheme.FONT_FOOTER);
        footer.setForeground(new Color(120, 140, 170));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 14, 0));
        return footer;
    }

    private JPanel makeCard(String label, String sub, Color color, ActionListener action) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2, true),
            BorderFactory.createEmptyBorder(16, 20, 16, 20)));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JLabel main   = new JLabel(label);
        main.setFont(UITheme.FONT_MENU);
        main.setForeground(color);
        JLabel detail = new JLabel("<html><i>" + sub + "</i></html>");
        detail.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        detail.setForeground(new Color(100, 110, 130));
        card.add(main, BorderLayout.CENTER);
        card.add(detail, BorderLayout.SOUTH);
        card.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                card.setBackground(new Color(
                    Math.min(color.getRed()+215,255),
                    Math.min(color.getGreen()+215,255),
                    Math.min(color.getBlue()+215,255)));
            }
            public void mouseExited(MouseEvent e)  { card.setBackground(UITheme.CARD_BG); }
            public void mouseClicked(MouseEvent e) { action.actionPerformed(null); }
        });
        return card;
    }

    private JPanel loadScaledImage(String path, int maxW, int maxH) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UITheme.CARD_BG);
        try {
            BufferedImage img = ImageIO.read(new File(path));
            if (img != null) {
                double scale = Math.min((double) maxW / img.getWidth(),
                                         (double) maxH / img.getHeight());
                int w = (int)(img.getWidth()  * scale);
                int h = (int)(img.getHeight() * scale);
                JLabel lbl = new JLabel(
                    new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH)));
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                wrapper.add(lbl, BorderLayout.CENTER);
                wrapper.setPreferredSize(new Dimension(w + 16, h + 16));
            }
        } catch (IOException ex) {
            wrapper.add(new JLabel("[Image not found: " + path + "]", SwingConstants.CENTER));
        }
        return wrapper;
    }
}
