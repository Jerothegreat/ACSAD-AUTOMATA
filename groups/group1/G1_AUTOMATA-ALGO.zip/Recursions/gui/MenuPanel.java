package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * MenuPanel — Main menu screen with a scrollable algorithm selection grid.
 */
public class MenuPanel extends JPanel {

    public MenuPanel(CardLayout cardLayout, JPanel parent, Runnable onExit) {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG);
        add(buildHeader(),                            BorderLayout.NORTH);
        add(buildCentre(cardLayout, parent, onExit), BorderLayout.CENTER);
        add(buildFooter(),                            BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.HEADER);
        header.setBorder(BorderFactory.createEmptyBorder(18, 32, 18, 32));
        JLabel title = new JLabel("AUTOMATA ", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Finals Laboratory Group Activity", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_SUB);
        sub.setForeground(new Color(180, 200, 255));
        JPanel box = new JPanel(new GridLayout(2, 1, 0, 3));
        box.setOpaque(false);
        box.add(title); box.add(sub);
        header.add(box, BorderLayout.CENTER);
        return header;
    }

    private JScrollPane buildCentre(CardLayout cardLayout, JPanel parent, Runnable onExit) {
        JPanel content = createContentPanel();

        CardLayout categoryLayout = new CardLayout();
        JPanel categoryCards = new JPanel(categoryLayout);
        categoryCards.setBackground(UITheme.BG);
        categoryCards.setAlignmentX(Component.CENTER_ALIGNMENT);
        categoryCards.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        content.add(buildCategoryChooser(categoryLayout, categoryCards));
        content.add(Box.createVerticalStrut(18));

        categoryCards.add(buildCategorySection(
            "Number Theory",
            "images/NumberTheory.png",
            new String[] {
                "Division Algorithm",
                "Euclidean Algorithm",
                "Collatz Conjecture"
            },
            new Color[] {
                UITheme.ACCENT_DIVISION,
                UITheme.ACCENT_EUCLID,
                UITheme.ACCENT_COLLATZ
            },
            new ActionListener[] {
                e -> cardLayout.show(parent, "DIVISION"),
                e -> cardLayout.show(parent, "EUCLIDEAN"),
                e -> cardLayout.show(parent, "COLLATZ")
            }), "NUMBER_THEORY");
        categoryCards.add(buildCategorySection(
            "Recursions",
            "images/image1.png",
            new String[] { "Fibonacci", "Lucas", "Tribonacci" },
            new Color[] {
                UITheme.ACCENT_FIBO,
                UITheme.ACCENT_LUCAS,
                UITheme.ACCENT_TRIBO
            },
            new ActionListener[] {
                e -> cardLayout.show(parent, "FIBONACCI"),
                e -> cardLayout.show(parent, "LUCAS"),
                e -> cardLayout.show(parent, "TRIBONACCI")
            }), "RECURSIONS");
        categoryCards.add(buildCategorySection(
            "String Algorithms",
            "images/StringAlgo.png",
            new String[] { "Palindrome" },
            new Color[] { UITheme.ACCENT_PALINDROME },
            new ActionListener[] { e -> cardLayout.show(parent, "PALINDROME") }), "STRING_ALGO");

        categoryLayout.show(categoryCards, "NUMBER_THEORY");
        content.add(categoryCards);
        content.add(Box.createVerticalStrut(16));
        content.add(buildExitWrap(onExit));
        return wrapScrollable(content);
    }

    private JLabel buildFooter() {
        JLabel footer = new JLabel("Choose a category first, then select an algorithm", SwingConstants.CENTER);
        footer.setFont(UITheme.FONT_FOOTER);
        footer.setForeground(new Color(120, 140, 170));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 14, 0));
        return footer;
    }

    private JPanel buildCategoryChooser(CardLayout categoryLayout, JPanel categoryCards) {
        JPanel chooserWrap = new JPanel(new BorderLayout());
        chooserWrap.setOpaque(false);
        chooserWrap.setAlignmentX(Component.CENTER_ALIGNMENT);
        chooserWrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JPanel chooser = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 10));
        chooser.setBackground(UITheme.CARD_BG);
        chooser.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.DIVIDER, 1, true),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)));

        chooser.add(makeMenuButton(
            "Number Theory", UITheme.ACCENT_DIVISION,
            e -> categoryLayout.show(categoryCards, "NUMBER_THEORY"), 190, 150));
        chooser.add(makeMenuButton(
            "Recursions", UITheme.ACCENT_FIBO,
            e -> categoryLayout.show(categoryCards, "RECURSIONS"), 190, 150));
        chooser.add(makeMenuButton(
            "String Algorithms", UITheme.ACCENT_PALINDROME,
            e -> categoryLayout.show(categoryCards, "STRING_ALGO"), 190, 150));

        chooserWrap.add(chooser, BorderLayout.CENTER);
        return chooserWrap;
    }

    private JPanel buildCategorySection(String title, String imagePath, String[] buttonLabels,
                                        Color[] buttonColors, ActionListener[] actions) {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(UITheme.CARD_BG);
        section.setAlignmentX(Component.CENTER_ALIGNMENT);
        section.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.DIVIDER, 1, true),
            BorderFactory.createEmptyBorder(20, 24, 20, 24)));
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JLabel heading = new JLabel(title, SwingConstants.CENTER);
        heading.setFont(UITheme.FONT_TITLE);
        heading.setForeground(UITheme.HEADER);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        section.add(heading);
        section.add(Box.createVerticalStrut(14));

        JPanel imagePanel = loadScaledImage(imagePath, 420, 200);
        imagePanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        imagePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.DIVIDER, 1, true),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)));
        section.add(imagePanel);
        section.add(Box.createVerticalStrut(18));

        JPanel buttonStack = new JPanel();
        buttonStack.setLayout(new BoxLayout(buttonStack, BoxLayout.Y_AXIS));
        buttonStack.setOpaque(false);
        buttonStack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonStack.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        for (int i = 0; i < buttonLabels.length; i++) {
            JButton button = makeMenuButton(buttonLabels[i], buttonColors[i], actions[i], 320, 180);
            buttonStack.add(button);
            if (i < buttonLabels.length - 1) {
                buttonStack.add(Box.createVerticalStrut(12));
            }
        }

        section.add(buttonStack);
        return section;
    }

    private JPanel createContentPanel() {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UITheme.BG);
        content.setBorder(BorderFactory.createEmptyBorder(24, 40, 16, 40));
        return content;
    }

    private JPanel buildExitWrap(Runnable onExit) {
        JButton exitBtn = new JButton("Exit Application");
        exitBtn.setFont(UITheme.FONT_BTN);
        exitBtn.setBackground(UITheme.ACCENT_EXIT);
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.setOpaque(true);
        exitBtn.setBorderPainted(false);
        exitBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        exitBtn.setBorder(BorderFactory.createEmptyBorder(8, 24, 8, 24));
        exitBtn.addActionListener(e -> onExit.run());

        JPanel exitWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        exitWrap.setBackground(UITheme.BG);
        exitWrap.add(exitBtn);
        return exitWrap;
    }

    private JScrollPane wrapScrollable(JComponent component) {
        JScrollPane scrollPane = new JScrollPane(
            component,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.setBackground(UITheme.BG);
        scrollPane.getViewport().setBackground(UITheme.BG);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        return scrollPane;
    }

    private JButton makeMenuButton(String label, Color color, ActionListener action,
                                   int preferredWidth, int minimumWidth) {
        JButton button = new JButton(label);
        button.setFont(UITheme.FONT_MENU);
        button.setForeground(color);
        button.setBackground(Color.WHITE);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        button.setPreferredSize(new Dimension(preferredWidth, 46));
        button.setMinimumSize(new Dimension(minimumWidth, 46));
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2, true),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        button.addActionListener(action);
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(
                    Math.min(color.getRed() + 215, 255),
                    Math.min(color.getGreen() + 215, 255),
                    Math.min(color.getBlue() + 215, 255)));
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.WHITE);
            }
        });
        return button;
    }

    private JPanel loadScaledImage(String path, int maxW, int maxH) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UITheme.CARD_BG);
        try {
            BufferedImage img = ImageIO.read(new File(path));
            if (img != null) {
                JLabel lbl = new JLabel();
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                wrapper.add(lbl, BorderLayout.CENTER);

                Runnable updateImage = () -> {
                    int availableWidth = wrapper.getWidth() > 0
                        ? Math.max(180, wrapper.getWidth() - 16)
                        : maxW;
                    double scale = Math.min((double) Math.min(maxW, availableWidth) / img.getWidth(),
                                             (double) maxH / img.getHeight());
                    int w = Math.max(1, (int) (img.getWidth() * scale));
                    int h = Math.max(1, (int) (img.getHeight() * scale));
                    lbl.setIcon(new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH)));
                    wrapper.revalidate();
                    wrapper.repaint();
                };

                wrapper.addComponentListener(new ComponentAdapter() {
                    @Override
                    public void componentResized(ComponentEvent e) {
                        updateImage.run();
                    }
                });

                SwingUtilities.invokeLater(updateImage);
                wrapper.setPreferredSize(new Dimension(Math.min(maxW, img.getWidth()) + 16,
                                                       Math.min(maxH, img.getHeight()) + 16));
            }
        } catch (IOException ex) {
            wrapper.add(new JLabel("[Image not found: " + path + "]", SwingConstants.CENTER));
        }
        return wrapper;
    }
}
