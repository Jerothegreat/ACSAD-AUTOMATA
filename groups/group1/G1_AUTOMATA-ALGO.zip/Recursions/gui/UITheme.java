package gui;

import java.awt.*;

/**
 * UITheme — shared colours, fonts, and spacing constants.
 */
public final class UITheme {
    private UITheme() {}

    public static final Color BG        = new Color(245, 248, 255);
    public static final Color HEADER    = new Color( 30,  60, 114);
    public static final Color CARD_BG   = Color.WHITE;
    public static final Color RESULT_BG = new Color(240, 245, 255);
    public static final Color DIVIDER   = new Color(200, 210, 230);
    public static final Color ERROR_BG  = new Color(255, 235, 235);
    public static final Color ERROR_FG  = new Color(160,  20,  20);

    public static final Color ACCENT_FIBO  = new Color( 30,  90, 180);
    public static final Color ACCENT_LUCAS = new Color(180, 120,   0);
    public static final Color ACCENT_TRIBO = new Color( 20, 140,  70);
    public static final Color ACCENT_COLLATZ = new Color(150,  70,  30);
    public static final Color ACCENT_DIVISION = new Color(  0, 130, 140);
    public static final Color ACCENT_EUCLID = new Color(130,  40,  90);
    public static final Color ACCENT_PALINDROME = new Color(105,  95,  20);
    public static final Color ACCENT_EXIT  = new Color(180,  30,  30);

    public static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD,  20);
    public static final Font FONT_SUB    = new Font("Segoe UI", Font.ITALIC,13);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  22);
    public static final Font FONT_MENU   = new Font("Segoe UI", Font.BOLD,  15);
    public static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BTN    = new Font("Segoe UI", Font.BOLD,  13);
    public static final Font FONT_BTN_SM = new Font("Segoe UI", Font.BOLD,  12);
    public static final Font FONT_INPUT  = new Font("Segoe UI", Font.BOLD,  14);
    public static final Font FONT_MONO   = new Font("Consolas",  Font.PLAIN, 13);
    public static final Font FONT_FOOTER = new Font("Segoe UI", Font.ITALIC,12);
}
