package gui;

import javax.swing.*;
import java.awt.*;
import logic.Collatz;
import logic.DivisionAlgorithm;
import logic.EuclideanAlgorithm;
import logic.Fibonacci;
import logic.Lucas;
import logic.Palindrome;
import logic.Tribonacci;

/**
 * RecursionApp — Main JFrame + Entry Point
 *
 * Wires logic classes to GUI panels via CardLayout.
 * Validation is handled in the logic package before any computation runs.
 *
 * Compile (from the Recursions folder):
 *   javac logic/*.java gui/*.java
 * Run:
 *   java gui.RecursionApp
 */
public class RecursionApp extends JFrame {

    public RecursionApp() {
        setTitle("Automata Lab Exercise (Finals)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(870, 680);
        setMinimumSize(new Dimension(780, 560));
        setLocationRelativeTo(null);

        CardLayout cardLayout = new CardLayout();
        JPanel     mainPanel  = new JPanel(cardLayout);
        mainPanel.setBackground(UITheme.BG);

        Runnable onExit = () -> {
            int c = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to exit?", "Exit",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (c == JOptionPane.YES_OPTION) System.exit(0);
        };

        // ── MENU ──────────────────────────────────────────────────────────────
        mainPanel.add(new MenuPanel(cardLayout, mainPanel, onExit), "MENU");

        // ── FIBONACCI ──────────────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            Fibonacci.NAME,
            UITheme.ACCENT_FIBO,
            Fibonacci.DESCRIPTION,
            Fibonacci.IMAGE_PATH,
            new String[] { Fibonacci.INPUT_HINT },
            inputs -> Fibonacci.validate(inputs[0]),
            validation -> buildSequenceOutput(
                Fibonacci.NAME, Fibonacci.getSequence(validation.getIntValue(0))),
            cardLayout, mainPanel), "FIBONACCI");

        // ── LUCAS ──────────────────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            Lucas.NAME,
            UITheme.ACCENT_LUCAS,
            Lucas.DESCRIPTION,
            Lucas.IMAGE_PATH,
            new String[] { Lucas.INPUT_HINT },
            inputs -> Lucas.validate(inputs[0]),
            validation -> buildSequenceOutput(
                Lucas.NAME, Lucas.getSequence(validation.getIntValue(0))),
            cardLayout, mainPanel), "LUCAS");

        // ── TRIBONACCI ─────────────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            Tribonacci.NAME,
            UITheme.ACCENT_TRIBO,
            Tribonacci.DESCRIPTION,
            Tribonacci.IMAGE_PATH,
            new String[] { Tribonacci.INPUT_HINT },
            inputs -> Tribonacci.validate(inputs[0]),
            validation -> buildSequenceOutput(
                Tribonacci.NAME, Tribonacci.getSequence(validation.getIntValue(0))),
            cardLayout, mainPanel), "TRIBONACCI");

        // ── COLLATZ ────────────────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            Collatz.NAME,
            UITheme.ACCENT_COLLATZ,
            Collatz.DESCRIPTION,
            Collatz.IMAGE_PATH,
            new String[] { Collatz.INPUT_HINT },
            inputs -> Collatz.validate(inputs[0]),
            validation -> buildCollatzOutput(validation.getIntValue(0)),
            cardLayout, mainPanel), "COLLATZ");

        // ── DIVISION ALGORITHM ────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            DivisionAlgorithm.NAME,
            UITheme.ACCENT_DIVISION,
            DivisionAlgorithm.DESCRIPTION,
            DivisionAlgorithm.IMAGE_PATH,
            DivisionAlgorithm.INPUT_HINTS,
            DivisionAlgorithm::validate,
            validation -> buildDivisionOutput(
                validation.getIntValue(0), validation.getIntValue(1)),
            cardLayout, mainPanel), "DIVISION");

        // ── EUCLIDEAN ALGORITHM ───────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            EuclideanAlgorithm.NAME,
            UITheme.ACCENT_EUCLID,
            EuclideanAlgorithm.DESCRIPTION,
            EuclideanAlgorithm.IMAGE_PATH,
            EuclideanAlgorithm.INPUT_HINTS,
            EuclideanAlgorithm::validate,
            validation -> buildEuclideanOutput(
                validation.getIntValue(0), validation.getIntValue(1)),
            cardLayout, mainPanel), "EUCLIDEAN");

        // ── PALINDROME ────────────────────────────────────────────────────────
        mainPanel.add(new AlgorithmPanel(
            Palindrome.NAME,
            UITheme.ACCENT_PALINDROME,
            Palindrome.DESCRIPTION,
            Palindrome.IMAGE_PATH,
            new String[] { Palindrome.INPUT_HINT },
            inputs -> Palindrome.validate(inputs[0]),
            validation -> buildPalindromeOutput(validation.getStringValue(0)),
            cardLayout, mainPanel), "PALINDROME");

        add(mainPanel);
        cardLayout.show(mainPanel, "MENU");
    }

    private String buildSequenceOutput(String name, long[] seq) {
        StringBuilder sb = new StringBuilder();
        sb.append("This program will find all the terms of the ").append(name).append(".\n\n");
        sb.append("Number of terms: ").append(seq.length).append("\n\n");
        sb.append("The ").append(name).append(" are:\n  ");
        for (int i = 0; i < seq.length; i++) {
            sb.append(seq[i]);
            if (i < seq.length - 1) sb.append(", ");
        }
        return sb.toString();
    }

    private String buildCollatzOutput(int initialValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("This program will generate the Collatz sequence.\n\n");
        sb.append("Initial value: ").append(initialValue).append("\n\n");
        sb.append("The Collatz sequence is:\n  ");
        sb.append(Collatz.getSequence(initialValue));
        return sb.toString();
    }

    private String buildDivisionOutput(int firstInput, int secondInput) {
        DivisionAlgorithm.Result result = DivisionAlgorithm.compute(firstInput, secondInput);
        StringBuilder sb = new StringBuilder();
        sb.append("This program will apply the Division Algorithm.\n\n");
        sb.append("Input integers: ").append(result.firstInput)
            .append(" and ").append(result.secondInput).append("\n");
        sb.append("Using the larger number as the dividend:\n  ");
        sb.append(result.dividend).append(" = ").append(result.divisor)
            .append(" (").append(result.quotient).append(") + ")
            .append(result.remainder).append("\n\n");
        sb.append("The dividend is ").append(result.dividend).append(".\n");
        sb.append("The divisor is ").append(result.divisor).append(".\n");
        sb.append("The quotient is ").append(result.quotient).append(".\n");
        sb.append("The remainder is ").append(result.remainder).append(".");
        return sb.toString();
    }

    private String buildEuclideanOutput(int firstInput, int secondInput) {
        EuclideanAlgorithm.Result result = EuclideanAlgorithm.compute(firstInput, secondInput);
        StringBuilder sb = new StringBuilder();
        sb.append("This program will apply the Euclidean Algorithm.\n\n");
        sb.append("Input integers: ").append(result.firstInput)
            .append(" and ").append(result.secondInput).append("\n\n");
        sb.append("Steps:\n  ")
            .append(result.steps.replace("\n", "\n  "))
            .append("\n\n");
        sb.append("The greatest common divisor of ")
            .append(result.dividend).append(" and ").append(result.divisor)
            .append(" is ").append(result.gcd).append(".\n");
        sb.append("The least common multiple of ")
            .append(result.dividend).append(" and ").append(result.divisor)
            .append(" is ").append(result.lcm).append(".");
        return sb.toString();
    }

    private String buildPalindromeOutput(String input) {
        Palindrome.Result result = Palindrome.analyze(input);
        StringBuilder sb = new StringBuilder();
        sb.append("This program will check whether the given text is a palindrome.\n\n");
        sb.append("Input text: ").append(result.originalInput).append("\n");
        sb.append("Character count: ").append(result.originalLength).append("\n");
        sb.append("Text without spaces: ").append(result.normalizedInput).append("\n");
        sb.append("Character count without spaces: ").append(result.normalizedLength)
            .append("\n\n");
        sb.append("Result:\n  ")
            .append(result.originalInput)
            .append(result.palindrome ? " is a palindrome." : " is not a palindrome.");
        return sb.toString();
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new RecursionApp().setVisible(true));
    }
}
