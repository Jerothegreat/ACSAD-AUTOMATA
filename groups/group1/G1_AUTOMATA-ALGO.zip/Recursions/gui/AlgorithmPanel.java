package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import logic.ValidationResult;

/**
 * Reusable screen for one-input and two-input algorithms.
 */
public class AlgorithmPanel extends JPanel {

    @FunctionalInterface
    public interface ValidateCallback {
        ValidationResult validate(String[] inputs);
    }

    @FunctionalInterface
    public interface ComputeCallback {
        String compute(ValidationResult validation);
    }

    public AlgorithmPanel(
            String seqName,
            Color accent,
            String description,
            String imagePath,
            String[] inputHints,
            ValidateCallback validator,
            ComputeCallback computer,
            CardLayout cardLayout,
            JPanel parentPanel) {

        setLayout(new BorderLayout());
        setBackground(UITheme.BG);

        add(buildHeader(seqName, accent, cardLayout, parentPanel), BorderLayout.NORTH);
        add(buildBody(accent, description, imagePath, inputHints, validator, computer),
            BorderLayout.CENTER);
    }

    private JPanel buildHeader(String seqName, Color accent,
                               CardLayout cardLayout, JPanel parentPanel) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(accent);
        header.setBorder(BorderFactory.createEmptyBorder(14, 28, 14, 28));

        JLabel title = new JLabel(seqName, SwingConstants.LEFT);
        title.setFont(UITheme.FONT_HEADER);
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        JButton backBtn = new JButton("<-  Back to Menu");
        backBtn.setFont(UITheme.FONT_BTN_SM);
        backBtn.setForeground(accent);
        backBtn.setBackground(Color.WHITE);
        backBtn.setFocusPainted(false);
        backBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1, true),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)));
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                backBtn.setBackground(new Color(235, 235, 235));
            }

            public void mouseExited(MouseEvent e) {
                backBtn.setBackground(Color.WHITE);
            }
        });
        backBtn.addActionListener(e -> cardLayout.show(parentPanel, "MENU"));
        header.add(backBtn, BorderLayout.EAST);
        return header;
    }

    private JScrollPane buildBody(
            Color accent,
            String description,
            String imagePath,
            String[] inputHints,
            ValidateCallback validator,
            ComputeCallback computer) {

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(UITheme.BG);
        body.setBorder(BorderFactory.createEmptyBorder(20, 36, 24, 36));

        if (imagePath != null && !imagePath.trim().isEmpty()) {
            JPanel imgWrapper = loadScaledImage(imagePath, 540, 190);
            imgWrapper.setAlignmentX(Component.CENTER_ALIGNMENT);
            imgWrapper.setBackground(Color.WHITE);
            imgWrapper.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.DIVIDER, 1, true),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));
            body.add(imgWrapper);
            body.add(Box.createVerticalStrut(14));
        }

        JPanel descCard = new JPanel(new BorderLayout());
        descCard.setBackground(Color.WHITE);
        descCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 125));
        descCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.DIVIDER, 1, true),
            BorderFactory.createEmptyBorder(12, 18, 12, 18)));
        JLabel descLabel = new JLabel(
            "<html><body style='width:510px;font-family:Segoe UI;font-size:12pt;'>"
            + description.replace("\n", "<br>") + "</body></html>");
        descCard.add(descLabel, BorderLayout.CENTER);
        body.add(descCard);
        body.add(Box.createVerticalStrut(18));

        JSeparator sep = new JSeparator();
        sep.setForeground(UITheme.DIVIDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        body.add(sep);
        body.add(Box.createVerticalStrut(16));

        JPanel inputSection = new JPanel();
        inputSection.setLayout(new BoxLayout(inputSection, BoxLayout.Y_AXIS));
        inputSection.setBackground(UITheme.BG);
        inputSection.setAlignmentX(Component.LEFT_ALIGNMENT);
        inputSection.setMaximumSize(new Dimension(Integer.MAX_VALUE, (inputHints.length * 42) + 52));

        JTextField[] inputFields = new JTextField[inputHints.length];
        for (int i = 0; i < inputHints.length; i++) {
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            row.setBackground(UITheme.BG);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

            JLabel label = new JLabel(inputHints[i]);
            label.setFont(UITheme.FONT_BODY);

            JTextField field = new JTextField(8);
            field.setFont(UITheme.FONT_INPUT);
            field.setHorizontalAlignment(JTextField.CENTER);
            field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(accent, 2, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));

            inputFields[i] = field;
            row.add(label);
            row.add(field);
            inputSection.add(row);

            if (i < inputHints.length - 1) {
                inputSection.add(Box.createVerticalStrut(8));
            }
        }

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttonRow.setBackground(UITheme.BG);
        buttonRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JButton computeBtn = new JButton("Compute  >");
        computeBtn.setFont(UITheme.FONT_BTN);
        computeBtn.setBackground(accent);
        computeBtn.setForeground(Color.WHITE);
        computeBtn.setFocusPainted(false);
        computeBtn.setOpaque(true);
        computeBtn.setBorderPainted(false);
        computeBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        computeBtn.setBorder(BorderFactory.createEmptyBorder(7, 22, 7, 22));

        JButton clearBtn = new JButton("Clear");
        clearBtn.setFont(UITheme.FONT_BTN_SM);
        clearBtn.setBackground(new Color(220, 225, 235));
        clearBtn.setForeground(new Color(60, 60, 80));
        clearBtn.setFocusPainted(false);
        clearBtn.setOpaque(true);
        clearBtn.setBorderPainted(false);
        clearBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearBtn.setBorder(BorderFactory.createEmptyBorder(7, 16, 7, 16));

        buttonRow.add(computeBtn);
        buttonRow.add(clearBtn);

        inputSection.add(Box.createVerticalStrut(10));
        inputSection.add(buttonRow);

        body.add(inputSection);
        body.add(Box.createVerticalStrut(14));

        JPanel resultCard = new JPanel(new BorderLayout(0, 6));
        resultCard.setBackground(UITheme.RESULT_BG);
        resultCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accent, 2, true),
            BorderFactory.createEmptyBorder(12, 18, 12, 18)));

        JLabel resultTitle = new JLabel("Output");
        resultTitle.setFont(UITheme.FONT_BTN_SM);
        resultTitle.setForeground(accent);
        resultCard.add(resultTitle, BorderLayout.NORTH);

        JTextArea resultArea = new JTextArea(6, 40);
        resultArea.setEditable(false);
        resultArea.setFont(UITheme.FONT_MONO);
        resultArea.setBackground(UITheme.RESULT_BG);
        resultArea.setForeground(new Color(20, 40, 80));
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBorder(null);
        resultArea.setText("The result will appear here after computation.");

        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultScroll.setBorder(null);
        resultCard.add(resultScroll, BorderLayout.CENTER);
        body.add(resultCard);

        ActionListener compute = e -> {
            String[] rawInputs = new String[inputFields.length];
            for (int i = 0; i < inputFields.length; i++) {
                rawInputs[i] = inputFields[i].getText();
            }

            ValidationResult result = validator.validate(rawInputs);
            if (!result.isValid()) {
                resultArea.setBackground(UITheme.ERROR_BG);
                resultArea.setForeground(UITheme.ERROR_FG);
                resultArea.setText(result.getMessage());
                resultArea.setCaretPosition(0);
                highlightFields(inputFields, UITheme.ERROR_FG);
                return;
            }

            resultArea.setBackground(UITheme.RESULT_BG);
            resultArea.setForeground(new Color(20, 40, 80));
            resultArea.setText(computer.compute(result));
            resultArea.setCaretPosition(0);
            highlightFields(inputFields, accent);
        };

        computeBtn.addActionListener(compute);
        for (JTextField field : inputFields) {
            field.addActionListener(compute);
        }

        clearBtn.addActionListener(e -> {
            for (JTextField field : inputFields) {
                field.setText("");
            }
            resultArea.setText("The result will appear here after computation.");
            resultArea.setBackground(UITheme.RESULT_BG);
            resultArea.setForeground(new Color(20, 40, 80));
            highlightFields(inputFields, accent);
            inputFields[0].requestFocus();
        });

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        scroll.setBackground(UITheme.BG);
        return scroll;
    }

    private void highlightFields(JTextField[] fields, Color color) {
        for (JTextField field : fields) {
            field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color, 2, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        }
    }

    private JPanel loadScaledImage(String path, int maxW, int maxH) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Color.WHITE);
        try {
            BufferedImage img = ImageIO.read(new File(path));
            if (img != null) {
                double scale = Math.min((double) maxW / img.getWidth(),
                                         (double) maxH / img.getHeight());
                int w = (int) (img.getWidth() * scale);
                int h = (int) (img.getHeight() * scale);
                JLabel lbl = new JLabel(
                    new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH)));
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                wrapper.add(lbl, BorderLayout.CENTER);
                wrapper.setPreferredSize(new Dimension(w + 16, h + 16));
            }
        } catch (IOException ex) {
            wrapper.add(new JLabel("[Image not found: " + path + "]",
                SwingConstants.CENTER));
        }
        return wrapper;
    }
}
