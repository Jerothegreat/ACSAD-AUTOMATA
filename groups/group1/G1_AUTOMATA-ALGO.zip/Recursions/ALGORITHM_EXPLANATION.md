# Algorithm Explanation and Computation Flow

This document explains the function and computation flow of each algorithm in the Java Swing application. The application is organized into three groups:

- Number Theory
- String Theory
- Recursions

## Overall System Flow

The application starts from `gui.RecursionApp`, which creates the main window and uses `CardLayout` to switch between screens. The menu screen is handled by `gui.MenuPanel`, while each algorithm screen is rendered through `gui.AlgorithmPanel`.

General flow:

1. The user selects an algorithm from the menu.
2. `AlgorithmPanel` displays the algorithm description, input field, buttons, and output area.
3. The user enters a value and clicks `Compute` or presses Enter.
4. The panel sends the raw input to the selected algorithm validator.
5. The validator returns a `ValidationResult`.
6. If validation fails, the output area displays an `INVALID INPUT` message.
7. If validation succeeds, the algorithm computes the result.
8. The computed result is formatted by `RecursionApp` and displayed in the output area.

Shared validation is handled by `logic.InputValidator`. It checks blank input, integer format, positive numbers, required text, valid pairs of numbers, and recursion term limits. The result is stored in `logic.ValidationResult`, which carries either validated numbers, validated text, or an error message.

## OOP Value Passing (Shared Pattern)

The app uses object-based callbacks and result objects to pass values between layers.

Main objects:

- `RecursionApp` wires each algorithm card.
- `AlgorithmPanel` receives callback objects (`ValidateCallback` and `ComputeCallback`).
- `ValidationResult` transports validated values from validator to compute stage.
- Algorithm-specific `Result` classes (for Division, Euclidean, Palindrome) transport computed output fields.

Shared value-passing flow:

```java
// RecursionApp: pass validator and compute callback objects into AlgorithmPanel
new AlgorithmPanel(
    EuclideanAlgorithm.NAME,
    ...,
    EuclideanAlgorithm::validate, // ValidateCallback
    validation -> buildEuclideanOutput(
        validation.getIntValue(0), // first validated int
        validation.getIntValue(1)  // second validated int
    ),
    cardLayout, mainPanel
);

// AlgorithmPanel: collects raw strings from JTextField[]
String[] rawInputs = ...;
ValidationResult result = validator.validate(rawInputs);
if (!result.isValid()) {
    // show INVALID INPUT message
} else {
    // pass ValidationResult into compute callback
    resultArea.setText(computer.compute(result));
}
```

Why this is OOP:

- Data is encapsulated in objects (`ValidationResult`, `Result`).
- UI and logic are separated by interfaces (callbacks), not hard-coded dependencies.
- Each algorithm class owns its own validation and compute behavior, while the panel reuses the same object contract.

## Number Theory

Number theory algorithms work with integer values and arithmetic rules.

### Collatz Sequence

Source file: `logic.Collatz`

Function:

The Collatz Sequence generates a list of numbers starting from a positive odd integer. The sequence continues until the value reaches `1`.

Validation:

- Input must not be blank.
- Input must be a whole number.
- Input must be positive.
- Input must be odd.

Computation flow:

1. Start with the validated input value.
2. Add the current value to the output sequence.
3. If the current value is `1`, stop the recursion.
4. If the current value is even, compute the next value as `n / 2`.
5. If the current value is odd, compute the next value as `3n + 1`.
6. Repeat the same process recursively until `1` is reached.

Example flow:

```text
Input: 5
5 is odd  -> 3(5) + 1 = 16
16 is even -> 16 / 2 = 8
8 is even  -> 8 / 2 = 4
4 is even  -> 4 / 2 = 2
2 is even  -> 2 / 2 = 1
Output: 5, 16, 8, 4, 2, 1
```

OOP value passing:

```java
// UI layer -> validator
ValidationResult vr = Collatz.validate(inputs[0]);

// Validator -> compute callback
int initialValue = vr.getIntValue(0);
String sequence = Collatz.getSequence(initialValue);

// RecursionApp formatting layer
buildCollatzOutput(initialValue);
```

Computation logic (inside algorithm class):

```java
private static void appendSequence(long value, StringBuilder sequence) {
    sequence.append(value);
    if (value == 1) return; // base case

    sequence.append(", ");
    if (value % 2 == 0) {
        appendSequence(value / 2, sequence);      // recursive even branch
    } else {
        appendSequence((3 * value) + 1, sequence); // recursive odd branch
    }
}
```

### Division Algorithm

Source file: `logic.DivisionAlgorithm`

Function:

The Division Algorithm takes two positive integers and expresses the larger number as:

```text
m = n(q) + r
```

where:

- `m` is the dividend.
- `n` is the divisor.
- `q` is the quotient.
- `r` is the remainder.
- `0 <= r < n`.

Validation:

- Both inputs must not be blank.
- Both inputs must be whole numbers.
- Both inputs must be positive integers.

Computation flow:

1. Compare the two validated inputs.
2. Use the larger number as the dividend.
3. Use the smaller number as the divisor.
4. Compute the quotient using integer division: `dividend / divisor`.
5. Compute the remainder using modulo: `dividend % divisor`.
6. Return the dividend, divisor, quotient, and remainder.

Example flow:

```text
Input: 17 and 5
Dividend: 17
Divisor: 5
Quotient: 17 / 5 = 3
Remainder: 17 % 5 = 2
Output: 17 = 5(3) + 2
```

OOP value passing:

```java
// UI layer -> validator (2-field input)
ValidationResult vr = DivisionAlgorithm.validate(inputs);

// Validator -> compute callback
int firstInput = vr.getIntValue(0);
int secondInput = vr.getIntValue(1);
DivisionAlgorithm.Result result = DivisionAlgorithm.compute(firstInput, secondInput);

// Result object fields consumed by RecursionApp formatter
result.dividend;
result.divisor;
result.quotient;
result.remainder;
```

Computation logic (inside algorithm class):

```java
int dividend = Math.max(firstInput, secondInput);
int divisor = Math.min(firstInput, secondInput);
int quotient = dividend / divisor;
int remainder = dividend % divisor;

return new Result(firstInput, secondInput, dividend, divisor, quotient, remainder);
```

### Euclidean Algorithm

Source file: `logic.EuclideanAlgorithm`

Function:

The Euclidean Algorithm finds the greatest common divisor, or GCD, of two positive integers. The program also computes the least common multiple, or LCM, using the GCD.

Validation:

- Both inputs must not be blank.
- Both inputs must be whole numbers.
- Both inputs must be positive integers.

Computation flow:

1. Compare the two validated inputs.
2. Use the larger number as `m`.
3. Use the smaller number as `n`.
4. Divide `m` by `n` and get the remainder.
5. If the remainder is not `0`, repeat the process using `n` as the new dividend and the remainder as the new divisor.
6. If the remainder becomes `0`, the last non-zero divisor is the GCD.
7. Compute the LCM using `(m * n) / gcd`.
8. Return the division steps, GCD, and LCM.

Example flow:

```text
Input: 48 and 18
48 = 18(2) + 12
18 = 12(1) + 6
12 = 6(2)
GCD: 6
LCM: (48 * 18) / 6 = 144
```

OOP value passing:

```java
// UI layer -> validator (2-field input)
ValidationResult vr = EuclideanAlgorithm.validate(inputs);

// Validator -> compute callback
int firstInput = vr.getIntValue(0);
int secondInput = vr.getIntValue(1);
EuclideanAlgorithm.Result result = EuclideanAlgorithm.compute(firstInput, secondInput);

// Result object fields consumed by RecursionApp formatter
result.steps; // division sequence text
result.gcd;   // final GCD
result.lcm;   // final LCM computed after gcd is known
```

Computation logic (inside algorithm class):

```java
int m = Math.max(firstInput, secondInput);
int n = Math.min(firstInput, secondInput);

appendSteps(m, n, steps); // builds the displayed division sequence
int gcd = gcd(m, n);      // recursive gcd
long lcm = ((long) m * (long) n) / gcd; // LCM derived after GCD

return new Result(firstInput, secondInput, m, n, steps.toString(), gcd, lcm);
```

```java
private static int gcd(int m, int n) {
    if (n == 0) return m;    // base case
    return gcd(n, m % n);    // recursive case
}
```

## String Theory

String theory algorithms work with text values and character comparison.

### Palindrome Checker

Source file: `logic.Palindrome`

Function:

The Palindrome Checker determines whether a word or phrase reads the same forward and backward. It ignores spaces and treats uppercase and lowercase letters as equal.

Validation:

- Input must not be blank.
- Input can be a word or a phrase.

Computation flow:

1. Trim the original input.
2. Remove all whitespace characters from the input.
3. Compare the leftmost and rightmost characters.
4. Convert both characters to lowercase before comparison.
5. If the characters are different, the text is not a palindrome.
6. If the characters match, move inward by comparing the next left and right characters.
7. Repeat recursively until the left index reaches or passes the right index.
8. If all compared characters match, the text is a palindrome.

Example flow:

```text
Input: Race car
Remove spaces: Racecar
Compare r and r -> same
Compare a and a -> same
Compare c and c -> same
Middle reached
Output: Race car is a palindrome.
```

OOP value passing:

```java
// UI layer -> validator
ValidationResult vr = Palindrome.validate(inputs[0]);

// Validator stores text payload
String cleanedInput = vr.getStringValue(0);
Palindrome.Result result = Palindrome.analyze(cleanedInput);

// Result object fields consumed by RecursionApp formatter
result.originalInput;
result.normalizedInput;
result.palindrome;
```

Computation logic (inside algorithm class):

```java
private static boolean isPalindrome(String input, int left, int right) {
    if (left >= right) return true; // base case

    if (Character.toLowerCase(input.charAt(left))
            != Character.toLowerCase(input.charAt(right))) {
        return false;
    }

    return isPalindrome(input, left + 1, right - 1); // recursive case
}
```

## Recursions

Recursion algorithms compute sequence values by calling the same method with smaller index values until a base case is reached.

### Fibonacci Numbers

Source file: `logic.Fibonacci`

Function:

The Fibonacci algorithm generates the first `n` Fibonacci numbers.

Definition:

```text
F(0) = 0
F(1) = 1
F(n) = F(n - 1) + F(n - 2), for n >= 2
```

Validation:

- Input must not be blank.
- Input must be a whole number.
- Input must be positive.
- Number of terms must be greater than `2`.
- Number of terms must not exceed `93` to avoid `long` overflow.

Computation flow:

1. Create an array that will hold the requested number of terms.
2. Set the base values: `F(0) = 0` and `F(1) = 1`.
3. For each index from `0` up to `terms - 1`, compute the Fibonacci value.
4. If the value was already computed, reuse the stored value.
5. If the value is not yet computed, recursively compute `F(n - 1)` and `F(n - 2)`.
6. Add the two previous values.
7. Store the result in the memo array.
8. Return the completed sequence.

Example flow:

```text
Input terms: 6
F(0) = 0
F(1) = 1
F(2) = F(1) + F(0) = 1
F(3) = F(2) + F(1) = 2
F(4) = F(3) + F(2) = 3
F(5) = F(4) + F(3) = 5
Output: 0, 1, 1, 2, 3, 5
```

OOP value passing:

```java
// UI layer -> validator
ValidationResult vr = Fibonacci.validate(inputs[0]);

// Validator -> compute callback
int terms = vr.getIntValue(0);
long[] sequence = Fibonacci.getSequence(terms);

// RecursionApp formatter consumes array
buildSequenceOutput(Fibonacci.NAME, sequence);
```

Computation logic (inside algorithm class):

```java
private static long compute(int n, long[] memo, boolean[] computed) {
    if (computed[n]) return memo[n]; // base/memoized case
    memo[n] = compute(n - 1, memo, computed) + compute(n - 2, memo, computed);
    computed[n] = true;
    return memo[n];
}
```

### Lucas Numbers

Source file: `logic.Lucas`

Function:

The Lucas algorithm generates the first `n` Lucas numbers. It is similar to Fibonacci, but it uses different starting values.

Definition:

```text
L(0) = 2
L(1) = 1
L(n) = L(n - 1) + L(n - 2), for n >= 2
```

Validation:

- Input must not be blank.
- Input must be a whole number.
- Input must be positive.
- Number of terms must be greater than `2`.
- Number of terms must not exceed `91` to avoid `long` overflow.

Computation flow:

1. Create an array that will hold the requested number of terms.
2. Set the base values: `L(0) = 2` and `L(1) = 1`.
3. For each index from `0` up to `terms - 1`, compute the Lucas value.
4. If the value was already computed, reuse the stored value.
5. If the value is not yet computed, recursively compute `L(n - 1)` and `L(n - 2)`.
6. Add the two previous values.
7. Store the result in the memo array.
8. Return the completed sequence.

Example flow:

```text
Input terms: 6
L(0) = 2
L(1) = 1
L(2) = L(1) + L(0) = 3
L(3) = L(2) + L(1) = 4
L(4) = L(3) + L(2) = 7
L(5) = L(4) + L(3) = 11
Output: 2, 1, 3, 4, 7, 11
```

OOP value passing:

```java
ValidationResult vr = Lucas.validate(inputs[0]);
int terms = vr.getIntValue(0);
long[] sequence = Lucas.getSequence(terms);
buildSequenceOutput(Lucas.NAME, sequence);
```

Computation logic (inside algorithm class):

```java
private static long compute(int n, long[] memo, boolean[] computed) {
    if (computed[n]) return memo[n]; // base/memoized case
    memo[n] = compute(n - 1, memo, computed) + compute(n - 2, memo, computed);
    computed[n] = true;
    return memo[n];
}
```

### Tribonacci Numbers

Source file: `logic.Tribonacci`

Function:

The Tribonacci algorithm generates the first `n` Tribonacci numbers. It works like Fibonacci, but each new value is the sum of the previous three values.

Definition:

```text
T(0) = 0
T(1) = 0
T(2) = 1
T(n) = T(n - 1) + T(n - 2) + T(n - 3), for n >= 3
```

Validation:

- Input must not be blank.
- Input must be a whole number.
- Input must be positive.
- Number of terms must be greater than `3`.
- Number of terms must not exceed `75` to avoid `long` overflow.

Computation flow:

1. Create an array that will hold the requested number of terms.
2. Set the base values: `T(0) = 0`, `T(1) = 0`, and `T(2) = 1`.
3. For each index from `0` up to `terms - 1`, compute the Tribonacci value.
4. If the value was already computed, reuse the stored value.
5. If the value is not yet computed, recursively compute `T(n - 1)`, `T(n - 2)`, and `T(n - 3)`.
6. Add the three previous values.
7. Store the result in the memo array.
8. Return the completed sequence.

Example flow:

```text
Input terms: 7
T(0) = 0
T(1) = 0
T(2) = 1
T(3) = T(2) + T(1) + T(0) = 1
T(4) = T(3) + T(2) + T(1) = 2
T(5) = T(4) + T(3) + T(2) = 4
T(6) = T(5) + T(4) + T(3) = 7
Output: 0, 0, 1, 1, 2, 4, 7
```

OOP value passing:

```java
ValidationResult vr = Tribonacci.validate(inputs[0]);
int terms = vr.getIntValue(0);
long[] sequence = Tribonacci.getSequence(terms);
buildSequenceOutput(Tribonacci.NAME, sequence);
```

Computation logic (inside algorithm class):

```java
private static long compute(int n, long[] memo, boolean[] computed) {
    if (computed[n]) return memo[n]; // base/memoized case
    memo[n] = compute(n - 1, memo, computed)
            + compute(n - 2, memo, computed)
            + compute(n - 3, memo, computed);
    computed[n] = true;
    return memo[n];
}
```

## Summary of Categories

| Category | Algorithms | Main Purpose |
| --- | --- | --- |
| Number Theory | Collatz Sequence, Division Algorithm, Euclidean Algorithm | Work with positive integers, division rules, GCD, and LCM |
| String Theory | Palindrome Checker | Analyze text by comparing characters recursively |
| Recursions | Fibonacci Numbers, Lucas Numbers, Tribonacci Numbers | Generate recursive number sequences |
