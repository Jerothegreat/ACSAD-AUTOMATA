package logic;

/**
 * Tribonacci Numbers — Recursive Implementation
 *
 * Definition : T(0) = 0,  T(1) = 0,  T(2) = 1
 * Recursion  : T(n) = T(n-1) + T(n-2) + T(n-3)   for n >= 3
 *
 * Validation rules (mirrors CollatzSequence pattern):
 *   1. Input must not be blank
 *   2. Input must be a whole number (integer)
 *   3. Input must be a positive integer (> 0)
 *   4. Input must be greater than MIN_TERMS (> 3)
 *   5. Input must not exceed MAX_TERMS to keep results inside long range
 */
public class Tribonacci {

    // ── Sequence metadata ─────────────────────────────────────────────────────
    public static final String NAME        = "Tribonacci Numbers";
    public static final String IMAGE_PATH  = "images/image4.png";
    public static final int    MIN_TERMS   = 3;
    public static final int    MAX_TERMS   = 75;
    public static final String INPUT_HINT  = "Enter number of terms (4 to 75):";
    public static final String DESCRIPTION =
        "This program will find all the terms of the Tribonacci Numbers.\n" +
        "Initial values:  T\u2080 = 0 ,  T\u2081 = 0 ,  T\u2082 = 1\n" +
        "Recursion rule:  T\u2099 = T\u2099\u208B\u2081 + T\u2099\u208B\u2082 + T\u2099\u208B\u2083   (for n \u2265 3)";

    // ── Input validation (called from GUI before compute) ─────────────────────
    /**
     * Validates a raw string input the same way CollatzSequence does:
     * blank check → parse check → range check.
     *
     * @param  input  raw text from the GUI text field
     * @return        ValidationResult.ok()   if input is acceptable
     *                ValidationResult.fail() with a message if not
     */
    public static ValidationResult validate(String input) {
        return InputValidator.validateTerms(input, MIN_TERMS, MAX_TERMS, NAME);
    }

    // ── Core recursive method ─────────────────────────────────────────────────
    /**
     * Computes the n-th Tribonacci number using pure recursion.
     * @param n  zero-based index (n >= 0)
     */
    public static long compute(int n) {
        long[] memo = new long[Math.max(n + 1, 3)];
        boolean[] computed = new boolean[memo.length];
        memo[0] = 0L;
        memo[1] = 0L;
        memo[2] = 1L;
        computed[0] = true;
        computed[1] = true;
        computed[2] = true;
        return compute(n, memo, computed);
    }

    private static long compute(int n, long[] memo, boolean[] computed) {
        if (computed[n]) return memo[n];
        memo[n] = compute(n - 1, memo, computed)
                + compute(n - 2, memo, computed)
                + compute(n - 3, memo, computed);
        computed[n] = true;
        return memo[n];
    }

    // ── Sequence builder ──────────────────────────────────────────────────────
    /**
     * Generates the first {@code terms} Tribonacci numbers.
     * Only call this after validate() returns ok().
     */
    public static long[] getSequence(int terms) {
        long[] seq = new long[terms];
        long[] memo = new long[Math.max(terms, 3)];
        boolean[] computed = new boolean[memo.length];
        memo[0] = 0L;
        memo[1] = 0L;
        memo[2] = 1L;
        computed[0] = true;
        computed[1] = true;
        computed[2] = true;

        for (int i = 0; i < terms; i++) seq[i] = compute(i, memo, computed);
        return seq;
    }
}
