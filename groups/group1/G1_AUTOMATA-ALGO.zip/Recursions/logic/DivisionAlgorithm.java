package logic;

/**
 * Division Algorithm
 *
 * Uses the larger input as the dividend and the smaller input as the divisor.
 */
public class DivisionAlgorithm {

    public static final String NAME        = "Division Algorithm";
    public static final String IMAGE_PATH  = null;
    public static final String[] INPUT_HINTS = {
        "Enter the first integer:",
        "Enter the second integer:"
    };
    public static final String DESCRIPTION =
        "This program applies the Division Algorithm to two positive integers.\n" +
        "The larger value is used as the dividend and the smaller value as the divisor.\n" +
        "It finds q and r such that m = n(q) + r, where 0 <= r < n.";

    public static ValidationResult validate(String[] inputs) {
        return InputValidator.validatePositiveIntegerPair(
            inputs[0], inputs[1], "the first integer", "the second integer");
    }

    public static Result compute(int firstInput, int secondInput) {
        int dividend = Math.max(firstInput, secondInput);
        int divisor  = Math.min(firstInput, secondInput);
        int quotient = dividend / divisor;
        int remainder = dividend % divisor;

        return new Result(firstInput, secondInput, dividend, divisor, quotient, remainder);
    }

    public static final class Result {
        public final int firstInput;
        public final int secondInput;
        public final int dividend;
        public final int divisor;
        public final int quotient;
        public final int remainder;

        private Result(
                int firstInput,
                int secondInput,
                int dividend,
                int divisor,
                int quotient,
                int remainder) {
            this.firstInput = firstInput;
            this.secondInput = secondInput;
            this.dividend = dividend;
            this.divisor = divisor;
            this.quotient = quotient;
            this.remainder = remainder;
        }
    }
}
