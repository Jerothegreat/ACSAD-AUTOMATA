package logic;

import java.util.Arrays;

/**
 * ValidationResult
 *
 * Returned by every logic class validate() method.
 * Mirrors the CollatzSequence pattern:
 *   - valid == true  → proceed to compute
 *   - valid == false → display message as "INVALID INPUT" feedback
 */
public class ValidationResult {

    private final boolean valid;
    private final String  message;
    private final int[]   values;

    private ValidationResult(boolean valid, String message, int[] values) {
        this.valid   = valid;
        this.message = message;
        this.values  = values == null ? new int[0] : Arrays.copyOf(values, values.length);
    }

    // ── Factory methods ───────────────────────────────────────────────────────
    /** Creates a passing result (no message needed). */
    public static ValidationResult ok() {
        return ok(new int[0]);
    }

    /** Creates a passing result with parsed integer values. */
    public static ValidationResult ok(int... values) {
        return new ValidationResult(true, "", values);
    }

    /**
     * Creates a failing result.
     * @param message  human-readable reason, shown in the GUI output area
     */
    public static ValidationResult fail(String message) {
        return new ValidationResult(false, "INVALID INPUT - " + message, new int[0]);
    }

    // ── Accessors ─────────────────────────────────────────────────────────────
    public boolean isValid()   { return valid; }
    public String  getMessage(){ return message; }
    public int     getIntValue(int index) { return values[index]; }
    public int     getValueCount() { return values.length; }
}
