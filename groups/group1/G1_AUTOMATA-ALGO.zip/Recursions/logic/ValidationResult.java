package logic;

import java.util.Arrays;

/**
 * ValidationResult
 *
 * Returned by every logic class validate() method.
 * Mirrors the CollatzSequence pattern:
 *   - valid == true  → proceed to compute
 *   - valid == false → display message as "INVALID INPUT" feedback
 */
public class ValidationResult {

    private final boolean valid;
    private final String  message;
    private final int[]   values;
    private final String[] textValues;

    private ValidationResult(boolean valid, String message, int[] values, String[] textValues) {
        this.valid = valid;
        this.message = message;
        this.values = values == null ? new int[0] : Arrays.copyOf(values, values.length);
        this.textValues = textValues == null
            ? new String[0]
            : Arrays.copyOf(textValues, textValues.length);
    }

    // ── Factory methods ───────────────────────────────────────────────────────
    /** Creates a passing result (no message needed). */
    public static ValidationResult ok() {
        return ok(new int[0]);
    }

    /** Creates a passing result with parsed integer values. */
    public static ValidationResult ok(int... values) {
        return new ValidationResult(true, "", values, new String[0]);
    }

    /** Creates a passing result with validated text values. */
    public static ValidationResult okText(String... values) {
        return new ValidationResult(true, "", new int[0], values);
    }

    /**
     * Creates a failing result.
     * @param message  human-readable reason, shown in the GUI output area
     */
    public static ValidationResult fail(String message) {
        return new ValidationResult(false, "INVALID INPUT - " + message, new int[0], new String[0]);
    }

    // ── Accessors ─────────────────────────────────────────────────────────────
    public boolean isValid()   { return valid; }
    public String  getMessage(){ return message; }
    public int     getIntValue(int index) { return values[index]; }
    public int     getValueCount() { return values.length; }
    public String  getStringValue(int index) { return textValues[index]; }
    public int     getStringCount() { return textValues.length; }
}
