package logic;

import java.math.BigInteger;

/**
 * Shared validation helpers for the Recursions app.
 *
 * Keeps the same validation flow across all algorithms:
 * blank check -> integer check -> algorithm-specific rule check.
 */
public final class InputValidator {

    private static final BigInteger MAX_INT = BigInteger.valueOf(Integer.MAX_VALUE);
    private static final BigInteger MIN_INT = BigInteger.valueOf(Integer.MIN_VALUE);

    private InputValidator() {}

    public static ValidationResult validateTerms(
            String input,
            int minTerms,
            int maxTerms,
            String sequenceName) {

        ValidationResult result = validatePositiveInteger(input, "the number of terms");
        if (!result.isValid()) return result;

        int terms = result.getIntValue(0);
        if (terms <= minTerms) {
            return ValidationResult.fail(
                "Number of terms must be greater than " + minTerms + ".");
        }

        if (terms > maxTerms) {
            return ValidationResult.fail(
                "Number of terms must not exceed " + maxTerms
                + " for " + sequenceName + " to avoid overflow.");
        }

        return ValidationResult.ok(terms);
    }

    public static ValidationResult validatePositiveOddInteger(String input, String fieldLabel) {
        ValidationResult result = parseRequiredInteger(input, fieldLabel);
        if (!result.isValid()) return result;

        int value = result.getIntValue(0);
        if (value <= 0 || value % 2 == 0) {
            return ValidationResult.fail(
                capitalize(fieldLabel) + " must be a positive odd integer.");
        }

        return ValidationResult.ok(value);
    }

    public static ValidationResult validatePositiveInteger(String input, String fieldLabel) {
        ValidationResult result = parseRequiredInteger(input, fieldLabel);
        if (!result.isValid()) return result;

        int value = result.getIntValue(0);
        if (value <= 0) {
            return ValidationResult.fail(
                capitalize(fieldLabel) + " must be a positive integer.");
        }

        return ValidationResult.ok(value);
    }

    public static ValidationResult validatePositiveIntegerPair(
            String firstInput,
            String secondInput,
            String firstLabel,
            String secondLabel) {

        ValidationResult first = validatePositiveInteger(firstInput, firstLabel);
        if (!first.isValid()) return first;

        ValidationResult second = validatePositiveInteger(secondInput, secondLabel);
        if (!second.isValid()) return second;

        return ValidationResult.ok(first.getIntValue(0), second.getIntValue(0));
    }

    public static ValidationResult validateRequiredText(String input, String fieldLabel) {
        if (input == null || input.trim().isEmpty()) {
            return ValidationResult.fail("Please enter " + fieldLabel + ".");
        }

        return ValidationResult.okText(input.trim());
    }

    private static ValidationResult parseRequiredInteger(String input, String fieldLabel) {
        if (input == null || input.trim().isEmpty()) {
            return ValidationResult.fail("Please enter " + fieldLabel + ".");
        }

        String trimmed = input.trim();
        if (!trimmed.matches("[+-]?\\d+")) {
            return ValidationResult.fail(
                capitalize(fieldLabel) + " must be a whole number (integer).");
        }

        try {
            BigInteger parsed = new BigInteger(trimmed);
            if (parsed.compareTo(MAX_INT) > 0 || parsed.compareTo(MIN_INT) < 0) {
                return ValidationResult.fail(
                    capitalize(fieldLabel)
                    + " is too large to process. Please enter a smaller whole number.");
            }

            return ValidationResult.ok(parsed.intValue());
        } catch (NumberFormatException e) {
            return ValidationResult.fail(
                capitalize(fieldLabel) + " must be a whole number (integer).");
        }
    }

    private static String capitalize(String text) {
        if (text == null || text.isEmpty()) return "Input";
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }
}
