package logic;

/**
 * Palindrome Checker
 *
 * Ignores spaces and compares letters without regard to case.
 */
public class Palindrome {

    public static final String NAME = "Palindrome Checker";
    public static final String IMAGE_PATH = null;
    public static final String INPUT_HINT = "Enter a word or phrase:";
    public static final String DESCRIPTION =
        "This program checks whether a word or phrase is a palindrome.\n" +
        "Spaces are ignored, and uppercase or lowercase letters are treated the same.";

    public static ValidationResult validate(String input) {
        return InputValidator.validateRequiredText(input, "a word or phrase");
    }

    public static Result analyze(String input) {
        String originalInput = input == null ? "" : input.trim();
        String normalizedInput = removeWhitespace(originalInput);
        boolean palindrome = isPalindrome(normalizedInput, 0, normalizedInput.length() - 1);
        return new Result(
            originalInput,
            normalizedInput,
            originalInput.length(),
            normalizedInput.length(),
            palindrome);
    }

    private static String removeWhitespace(String input) {
        StringBuilder cleaned = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (!Character.isWhitespace(ch)) {
                cleaned.append(ch);
            }
        }
        return cleaned.toString();
    }

    private static boolean isPalindrome(String input, int left, int right) {
        if (left >= right) return true;

        if (Character.toLowerCase(input.charAt(left))
                != Character.toLowerCase(input.charAt(right))) {
            return false;
        }

        return isPalindrome(input, left + 1, right - 1);
    }

    public static final class Result {
        public final String originalInput;
        public final String normalizedInput;
        public final int originalLength;
        public final int normalizedLength;
        public final boolean palindrome;

        private Result(
                String originalInput,
                String normalizedInput,
                int originalLength,
                int normalizedLength,
                boolean palindrome) {
            this.originalInput = originalInput;
            this.normalizedInput = normalizedInput;
            this.originalLength = originalLength;
            this.normalizedLength = normalizedLength;
            this.palindrome = palindrome;
        }
    }
}
