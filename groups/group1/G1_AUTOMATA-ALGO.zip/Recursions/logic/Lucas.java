package logic;

/**
 * Lucas Numbers — Recursive Implementation
 *
 * Definition : L(0) = 2,  L(1) = 1
 * Recursion  : L(n) = L(n-1) + L(n-2)   for n >= 2
 *
 * Validation rules (mirrors CollatzSequence pattern):
 *   1. Input must not be blank
 *   2. Input must be a whole number (integer)
 *   3. Input must be a positive integer (> 0)
 *   4. Input must be greater than MIN_TERMS (> 2)
 *   5. Input must not exceed MAX_TERMS to keep results inside long range
 */
public class Lucas {

    // ── Sequence metadata ─────────────────────────────────────────────────────
    public static final String NAME        = "Lucas Numbers";
    public static final String IMAGE_PATH  = "images/image3.png";
    public static final int    MIN_TERMS   = 2;
    public static final int    MAX_TERMS   = 91;
    public static final String INPUT_HINT  = "Enter number of terms (3 to 91):";
    public static final String DESCRIPTION =
        "This program will find all the terms of the Lucas Numbers.\n" +
        "Initial values:  L\u2080 = 2 ,  L\u2081 = 1\n" +
        "Recursion rule:  L\u2099 = L\u2099\u208B\u2081 + L\u2099\u208B\u2082   (for n \u2265 2)";

    // ── Input validation (called from GUI before compute) ─────────────────────
    /**
     * Validates a raw string input the same way CollatzSequence does:
     * blank check → parse check → range check.
     *
     * @param  input  raw text from the GUI text field
     * @return        ValidationResult.ok()   if input is acceptable
     *                ValidationResult.fail() with a message if not
     */
    public static ValidationResult validate(String input) {
        return InputValidator.validateTerms(input, MIN_TERMS, MAX_TERMS, NAME);
    }

    // ── Core recursive method ─────────────────────────────────────────────────
    /**
     * Computes the n-th Lucas number using pure recursion.
     * @param n  zero-based index (n >= 0)
     */
    public static long compute(int n) {
        long[] memo = new long[Math.max(n + 1, 2)];
        boolean[] computed = new boolean[memo.length];
        memo[0] = 2L;
        memo[1] = 1L;
        computed[0] = true;
        computed[1] = true;
        return compute(n, memo, computed);
    }

    private static long compute(int n, long[] memo, boolean[] computed) {
        if (computed[n]) return memo[n];
        memo[n] = compute(n - 1, memo, computed) + compute(n - 2, memo, computed);
        computed[n] = true;
        return memo[n];
    }

    // ── Sequence builder ──────────────────────────────────────────────────────
    /**
     * Generates the first {@code terms} Lucas numbers.
     * Only call this after validate() returns ok().
     */
    public static long[] getSequence(int terms) {
        long[] seq = new long[terms];
        long[] memo = new long[Math.max(terms, 2)];
        boolean[] computed = new boolean[memo.length];
        memo[0] = 2L;
        memo[1] = 1L;
        computed[0] = true;
        computed[1] = true;

        for (int i = 0; i < terms; i++) seq[i] = compute(i, memo, computed);
        return seq;
    }
}
