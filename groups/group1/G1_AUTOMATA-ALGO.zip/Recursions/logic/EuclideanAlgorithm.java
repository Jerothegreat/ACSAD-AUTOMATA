package logic;

/**
 * Euclidean Algorithm
 *
 * Repeatedly applies the Division Algorithm to compute the GCD and LCM.
 */
public class EuclideanAlgorithm {

    public static final String NAME        = "Euclidean Algorithm";
    public static final String IMAGE_PATH  = null;
    public static final String[] INPUT_HINTS = {
        "Enter the first integer:",
        "Enter the second integer:"
    };
    public static final String DESCRIPTION =
        "This program applies the Euclidean Algorithm to two positive integers.\n" +
        "It repeatedly performs the Division Algorithm until the remainder becomes 0.\n" +
        "The last non-zero divisor is the GCD, and the LCM is computed from the GCD.";

    public static ValidationResult validate(String[] inputs) {
        return InputValidator.validatePositiveIntegerPair(
            inputs[0], inputs[1], "the first integer", "the second integer");
    }

    public static Result compute(int firstInput, int secondInput) {
        int m = Math.max(firstInput, secondInput);
        int n = Math.min(firstInput, secondInput);
        StringBuilder steps = new StringBuilder();

        appendSteps(m, n, steps);

        int gcd = gcd(m, n);
        long lcm = ((long) m * (long) n) / gcd;

        return new Result(firstInput, secondInput, m, n, steps.toString(), gcd, lcm);
    }

    private static int gcd(int m, int n) {
        if (n == 0) return m;
        return gcd(n, m % n);
    }

    private static void appendSteps(int m, int n, StringBuilder steps) {
        int quotient = m / n;
        int remainder = m % n;

        steps.append(m).append(" = ").append(n).append(" (").append(quotient).append(")");
        if (remainder != 0) {
            steps.append(" + ").append(remainder).append("\n");
            appendSteps(n, remainder, steps);
        }
    }

    public static final class Result {
        public final int firstInput;
        public final int secondInput;
        public final int dividend;
        public final int divisor;
        public final String steps;
        public final int gcd;
        public final long lcm;

        private Result(
                int firstInput,
                int secondInput,
                int dividend,
                int divisor,
                String steps,
                int gcd,
                long lcm) {
            this.firstInput = firstInput;
            this.secondInput = secondInput;
            this.dividend = dividend;
            this.divisor = divisor;
            this.steps = steps;
            this.gcd = gcd;
            this.lcm = lcm;
        }
    }
}
