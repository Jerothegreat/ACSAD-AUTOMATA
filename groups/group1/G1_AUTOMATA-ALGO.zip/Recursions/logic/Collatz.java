package logic;

/**
 * Collatz Sequence
 *
 * Starts from a positive odd integer and continues until the sequence reaches 1.
 */
public class Collatz {

    public static final String NAME        = "Collatz Sequence";
    public static final String IMAGE_PATH  = null;
    public static final String INPUT_HINT  = "Enter the initial value:";
    public static final String DESCRIPTION =
        "This program will generate the Collatz sequence for a positive odd integer.\n" +
        "If n is odd, the next term is 3n + 1.\n" +
        "If n is even, the next term is n / 2.\n" +
        "The sequence stops when it reaches 1.";

    public static ValidationResult validate(String input) {
        return InputValidator.validatePositiveOddInteger(input, "the initial value");
    }

    public static String getSequence(int initialValue) {
        StringBuilder sequence = new StringBuilder();
        appendSequence(initialValue, sequence);
        return sequence.toString();
    }

    private static void appendSequence(long value, StringBuilder sequence) {
        sequence.append(value);
        if (value == 1) return;

        sequence.append(", ");
        if (value % 2 == 0) {
            appendSequence(value / 2, sequence);
        } else {
            appendSequence((3 * value) + 1, sequence);
        }
    }
}
