#!/bin/bash
javac logic/*.java gui/*.java
[ $? -ne 0 ] && echo 'Compilation FAILED.' && exit 1
java gui.RecursionApp
