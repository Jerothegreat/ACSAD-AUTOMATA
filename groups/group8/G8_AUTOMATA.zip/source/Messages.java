public final class Messages {

    private Messages() {
    }
    public static final String INPUT_GREATER_THAN_TWO = "Input must be greater than 2.";
    public static final String INPUT_GREATER_THAN_THREE = "Input must be greater than 3.";
    public static final String INVALID_NEGATIVE = "Input must be a positive integer.";
    public static final String INVALID_EVEN_NUMBER = "Input must be an odd number";
    public static final String EMPTY_INTEGER_INPUT = "Field is empty. Enter a positive integer.";
    public static final String INVALID_INTEGER_INPUT = "Input must be a positive integer.";
    public static final String EMPTY_STRING_INPUT = "Field is empty. Enter a word.";
}
