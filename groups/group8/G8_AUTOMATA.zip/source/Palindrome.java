public final class Palindrome {

    private Palindrome() {
    }

    public static String validate(String text) {
        if (text.isEmpty()) {
            return Messages.EMPTY_STRING_INPUT;
        }
        return null;
    }

    public static int getLength(String text) {
        return text.length();
    }

    public static boolean isPalindrome(String text) {
        if (text.isEmpty()) {
            return false;
        }

        int leftIndex = 0;
        int rightIndex = text.length() - 1;

        while (leftIndex < rightIndex) {
            char left = text.charAt(leftIndex);
            char right = text.charAt(rightIndex);

            if (left == ' ') {
                leftIndex++;
                continue;
            }
            if (right == ' ') {
                rightIndex--;
                continue;
            }

            if (left >= 'A' && left <= 'Z') {
                left += 32;
            }
            if (right >= 'A' && right <= 'Z') {
                right += 32;
            }

            if (left != right) {
                return false;
            }

            leftIndex++;
            rightIndex--;
        }

        return true;
    }

    public static String buildResult(String text) {
        StringBuilder result = new StringBuilder();
        result.append("Input   :  ").append(text).append("\n");
        result.append("Length  :  ").append(String.format("%,d", getLength(text))).append("\n\n");
        result.append(isPalindrome(text)
            ? "This string is a palindrome."
            : "This string is not a palindrome.");
        return result.toString();
    }
}
