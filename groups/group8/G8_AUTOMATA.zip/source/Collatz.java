public final class Collatz {

    private Collatz() {
    }

    public static String validate(long number) {
        if (number <= 0) {
            return Messages.INVALID_NEGATIVE;
        }
        if (number % 2 == 0) {
            return Messages.INVALID_EVEN_NUMBER;
        }
        return null;
    }

    public static String buildResult(long number) {
        StringBuilder result = new StringBuilder("The Collatz sequence are: ");
        result.append(number);

        int steps = 0;
        while (number != 1) {
            if ((number % 2) == 1) {
                number = (3 * number) + 1;
            } else {
                number /= 2;
            }

            steps++;
            result.append(", ");
            result.append(number);
        }

        return result.toString();
    }
}
