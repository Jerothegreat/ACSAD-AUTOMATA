public final class EuclideanAlgo {

    private EuclideanAlgo() {
    }

    public static String validate(int first, int second) {
        if (first <= 0 || second <= 0) {
            return Messages.INVALID_NEGATIVE;
        }
        return null;
    }

    public static String buildResult(int first, int second) {
        int dividend = Math.max(first, second);
        int divisor = Math.min(first, second);
        int originalDividend = dividend;
        int originalDivisor = divisor;
        StringBuilder steps = new StringBuilder();

        while (divisor != 0) {
            int temp = dividend;
            int quotient = 0;

            while (temp >= divisor) {
                temp -= divisor;
                quotient++;
            }

            int remainder = temp;

            if (remainder != 0) {
                steps.append(dividend)
                    .append(" = ")
                    .append(divisor)
                    .append(" (")
                    .append(quotient)
                    .append(") + ")
                    .append(remainder)
                    .append("\n");
            } else {
                steps.append(dividend)
                    .append(" = ")
                    .append(divisor)
                    .append(" (")
                    .append(quotient)
                    .append(")\n");
            }

            dividend = divisor;
            divisor = remainder;
        }

        int gcd = dividend;
        int lcm = (first * second) / gcd;
        String formattedOriginalDividend = String.format("%,d", originalDividend);
        String formattedOriginalDivisor = String.format("%,d", originalDivisor);
        String formattedGcd = String.format("%,d", gcd);
        String formattedLcm = String.format("%,d", lcm);

        StringBuilder result = new StringBuilder();
        result.append("SOLUTION:\n");
        result.append(steps);
        result.append("\nThe integers are ")
            .append(formattedOriginalDividend)
            .append(" and ")
            .append(formattedOriginalDivisor)
            .append("\n");
        result.append("The greatest common divisor of ")
            .append(formattedOriginalDividend)
            .append(" and ")
            .append(formattedOriginalDivisor)
            .append(" is ")
            .append(formattedGcd)
            .append("\n");
        result.append("The least common multiple of ")
            .append(formattedOriginalDividend)
            .append(" and ")
            .append(formattedOriginalDivisor)
            .append(" is ")
            .append(formattedLcm);
        return result.toString();
    }
}
