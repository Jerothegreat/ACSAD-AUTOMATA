public final class DivisionAlgo {

    private DivisionAlgo() {
    }

    public static String validate(int first, int second) {
        if (first <= 0 || second <= 0) {
            return Messages.INVALID_NEGATIVE;
        }
        return null;
    }

    public static String buildResult(int first, int second) {
        int dividend = Math.max(first, second);
        int divisor = Math.min(first, second);
        int quotient = 0;
        int remainder = dividend;

        while (remainder >= divisor) {
            remainder -= divisor;
            quotient++;
        }

        StringBuilder result = new StringBuilder();
        result.append("SOLUTION:\n");
        result.append(dividend)
            .append(" = ")
            .append(divisor)
            .append(" (")
            .append(quotient)
            .append(") + ")
            .append(remainder)
            .append("\n\n");
        result.append("The dividend is ").append(String.format("%,d",dividend)).append("\n");
        result.append("The divisor is ").append(String.format("%,d",divisor)).append("\n");
        result.append("The quotient is ").append(String.format("%,d",quotient))
            .append(" and the remainder is ")
            .append(String.format("%,d",remainder));
        return result.toString();
    }
}
