public final class Fibonacci {

    private Fibonacci() {
    }

    public static String validate(int n) {
        if (n <= 0) {
            return Messages.INVALID_NEGATIVE;
        }
        if (n <= 2) {
            return Messages.INPUT_GREATER_THAN_TWO;
        }
        return null;
    }

    public static String generate(int n) {
        long[] values = new long[n];
        values[0] = 0;
        if (n > 1) {
            values[1] = 1;
        }

        for (int index = 2; index < n; index++) {
            values[index] = values[index - 1] + values[index - 2];
        }

        return formatSequence(values);
    }

    public static String buildResult(int n) {
        return "The Fibonacci numbers are: " + generate(n);
    }

    private static String formatSequence(long[] values) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < values.length; index++) {
            if (index > 0) {
                builder.append(", ");
            }
            builder.append(values[index]);
        }
        return builder.toString();
    }
}
