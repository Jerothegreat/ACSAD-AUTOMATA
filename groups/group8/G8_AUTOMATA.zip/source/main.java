import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class main extends JFrame {

    private static final Color BG_DARK = new Color(0x0F, 0x0F, 0x14);
    private static final Color BG_CARD = new Color(0x18, 0x18, 0x22);
    private static final Color BG_INPUT = new Color(0x22, 0x22, 0x30);
    private static final Color ACCENT = new Color(0x7C, 0x3A, 0xFF);
    private static final Color ACCENT_HOVER = new Color(0x9D, 0x65, 0xFF);
    private static final Color TEXT_PRIMARY = new Color(0xF0, 0xEE, 0xFF);
    private static final Color TEXT_DIM = new Color(0x88, 0x84, 0xA8);
    private static final Color TEXT_OUTPUT = new Color(0xB8, 0xFF, 0xD6);
    private static final Color TEXT_ERROR = new Color(0xFF, 0x7B, 0x7B);
    private static final Color BORDER_LINE = new Color(0x35, 0x32, 0x55);
    private static final Color BTN_RESET_BG = new Color(0x2A, 0x2A, 0x3C);

    private static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("SansSerif", Font.BOLD, 12);
    private static final Font FONT_INPUT = new Font("Monospaced", Font.PLAIN, 13);
    private static final Font FONT_OUTPUT = new Font("Monospaced", Font.PLAIN, 13);
    private static final Font FONT_BTN = new Font("SansSerif", Font.BOLD, 12);
    private static final Font FONT_MENU = new Font("SansSerif", Font.BOLD, 13);
    private static final Font FONT_BACK = new Font("SansSerif", Font.PLAIN, 11);

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardPanel = new JPanel(cardLayout);

    public main() {
        setTitle("Automata Laboratory Activities - Algorithm Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(660, 820);
        setLocationRelativeTo(null);
        setBackground(BG_DARK);

        cardPanel.setBackground(BG_DARK);
        cardPanel.add(createMainMenu(), "MENU");
        cardPanel.add(createPalindromePanel(), "PALINDROME");
        cardPanel.add(createDivisionPanel(), "DIVISION");
        cardPanel.add(createEuclideanPanel(), "EUCLIDEAN");
        cardPanel.add(createCollatzPanel(), "COLLATZ");
        cardPanel.add(createFibonacciPanel(), "FIBONACCI");
        cardPanel.add(createLucasPanel(), "LUCAS");
        cardPanel.add(createTribonacciPanel(), "TRIBONACCI");

        setContentPane(cardPanel);
        setVisible(true);
    }

    private JPanel createMainMenu() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_DARK);
        panel.setBorder(new EmptyBorder(36, 40, 36, 40));

        JPanel header = new JPanel();
        header.setBackground(BG_DARK);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(new EmptyBorder(0, 0, 28, 0));

        JLabel badge = new JLabel("DISCRETE MATH TOOLKIT");
        badge.setFont(new Font("SansSerif", Font.BOLD, 9));
        badge.setForeground(ACCENT);
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);
        badge.setBorder(new CompoundBorder(
            new LineBorder(ACCENT, 1, true),
            new EmptyBorder(3, 8, 3, 8)
        ));

        JLabel title = new JLabel("Automata Laboratory Activities");
        title.setFont(FONT_TITLE);
        title.setForeground(TEXT_PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        title.setBorder(new EmptyBorder(12, 0, 4, 0));

        JLabel subtitle = new JLabel("Select an algorithm to get started");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_DIM);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        header.add(badge);
        header.add(title);
        header.add(subtitle);

        JPanel menu = new JPanel();
        menu.setBackground(BG_DARK);
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));

        String[][] items = {
            {"01", "Palindrome Checker", "PALINDROME"},
            {"02", "Division Algorithm", "DIVISION"},
            {"03", "Euclidean Algorithm", "EUCLIDEAN"},
            {"04", "Collatz Sequence", "COLLATZ"},
            {"05", "Fibonacci Numbers", "FIBONACCI"},
            {"06", "Lucas Numbers", "LUCAS"},
            {"07", "Tribonacci Numbers", "TRIBONACCI"}
        };

        for (String[] item : items) {
            menu.add(menuCard(item[0], item[1], item[2]));
            menu.add(Box.createVerticalStrut(8));
        }

        panel.add(header, BorderLayout.NORTH);
        panel.add(menu, BorderLayout.CENTER);
        return panel;
    }

    private JPanel menuCard(String number, String label, String card) {
        JPanel panel = new JPanel(new BorderLayout(12, 0));
        panel.setBackground(BG_CARD);
        panel.setBorder(new CompoundBorder(
            new LineBorder(BORDER_LINE, 1, true),
            new EmptyBorder(14, 18, 14, 18)
        ));
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        panel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel numberLabel = new JLabel(number);
        numberLabel.setFont(new Font("Monospaced", Font.BOLD, 11));
        numberLabel.setForeground(ACCENT);
        numberLabel.setPreferredSize(new Dimension(26, 20));

        JLabel nameLabel = new JLabel(label);
        nameLabel.setFont(FONT_MENU);
        nameLabel.setForeground(TEXT_PRIMARY);

        JLabel arrow = new JLabel("->");
        arrow.setFont(new Font("SansSerif", Font.PLAIN, 14));
        arrow.setForeground(TEXT_DIM);

        panel.add(numberLabel, BorderLayout.WEST);
        panel.add(nameLabel, BorderLayout.CENTER);
        panel.add(arrow, BorderLayout.EAST);

        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                panel.setBackground(new Color(0x22, 0x1E, 0x3A));
                panel.setBorder(new CompoundBorder(
                    new LineBorder(ACCENT, 1, true),
                    new EmptyBorder(14, 18, 14, 18)
                ));
                arrow.setForeground(ACCENT_HOVER);
                panel.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                panel.setBackground(BG_CARD);
                panel.setBorder(new CompoundBorder(
                    new LineBorder(BORDER_LINE, 1, true),
                    new EmptyBorder(14, 18, 14, 18)
                ));
                arrow.setForeground(TEXT_DIM);
                panel.repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(cardPanel, card);
            }
        });

        return panel;
    }

    private JPanel createFibonacciPanel() {
        return createSingleInputPanel(
            "Fibonacci Numbers",
            "05",
            "Number of terms  (n > 2)",
            (input, output) -> {
                int value = parseInt(input, output);
                if (value == Integer.MIN_VALUE) {
                    return;
                }
                String error = Fibonacci.validate(value);
                if (error != null) {
                    showError(output, error);
                    return;
                }
                showResult(output, Fibonacci.buildResult(value));
            }
        );
    }

    private JPanel createLucasPanel() {
        return createSingleInputPanel(
            "Lucas Numbers",
            "06",
            "Number of terms  (n > 2)",
            (input, output) -> {
                int value = parseInt(input, output);
                if (value == Integer.MIN_VALUE) {
                    return;
                }
                String error = Lucas.validate(value);
                if (error != null) {
                    showError(output, error);
                    return;
                }
                showResult(output, Lucas.buildResult(value));
            }
        );
    }

    private JPanel createTribonacciPanel() {
        return createSingleInputPanel(
            "Tribonacci Numbers",
            "07",
            "Number of terms  (n > 3)",
            (input, output) -> {
                int value = parseInt(input, output);
                if (value == Integer.MIN_VALUE) {
                    return;
                }
                String error = Tribonacci.validate(value);
                if (error != null) {
                    showError(output, error);
                    return;
                }
                showResult(output, Tribonacci.buildResult(value));
            }
        );
    }

    private JPanel createCollatzPanel() {
        return createSingleInputPanel(
            "Collatz Sequence",
            "04",
            "Initial value  (must be > 2)",
            (input, output) -> {
                if (isBlank(input)) {
                    showError(output, Messages.EMPTY_INTEGER_INPUT);
                    return;
                }
                try {
                    long value = Long.parseLong(input.getText().trim());
                    String error = Collatz.validate(value);
                    if (error != null) {
                        showError(output, error);
                        return;
                    }
                    showResult(output, Collatz.buildResult(value));
                } catch (NumberFormatException ex) {
                    showError(output, Messages.INVALID_INTEGER_INPUT);
                }
            }
        );
    }

    private JPanel createEuclideanPanel() {
        return createDoubleInputPanel(
            "Euclidean Algorithm",
            "03",
            "First integer",
            "Second integer",
            (input1, input2, output) -> {
                if (isBlank(input1) || isBlank(input2)) {
                    showError(output, Messages.EMPTY_INTEGER_INPUT);
                    return;
                }
                try {
                    int first = Integer.parseInt(input1.getText().trim());
                    int second = Integer.parseInt(input2.getText().trim());
                    String error = EuclideanAlgo.validate(first, second);
                    if (error != null) {
                        showError(output, error);
                        return;
                    }
                    showResult(output, EuclideanAlgo.buildResult(first, second));
                } catch (NumberFormatException ex) {
                    showError(output, Messages.INVALID_INTEGER_INPUT);
                }
            }
        );
    }

    private JPanel createDivisionPanel() {
        return createDoubleInputPanel(
            "Division Algorithm",
            "02",
            "First integer",
            "Second integer",
            (input1, input2, output) -> {
                if (isBlank(input1) || isBlank(input2)) {
                    showError(output, Messages.EMPTY_INTEGER_INPUT);
                    return;
                }
                try {
                    int first = Integer.parseInt(input1.getText().trim());
                    int second = Integer.parseInt(input2.getText().trim());
                    String error = DivisionAlgo.validate(first, second);
                    if (error != null) {
                        showError(output, error);
                        return;
                    }
                    showResult(output, DivisionAlgo.buildResult(first, second));
                } catch (NumberFormatException ex) {
                    showError(output, Messages.INVALID_INTEGER_INPUT);
                }
            }
        );
    }

    private JPanel createPalindromePanel() {
        return createSingleInputPanel(
            "Palindrome Checker",
            "01",
            "Enter a word or phrase",
            (input, output) -> {
                String text = input.getText();
                String error = Palindrome.validate(text);
                if (error != null) {
                    showError(output, error);
                    return;
                }
                showResult(output, Palindrome.buildResult(text));
            }
        );
    }

    @FunctionalInterface
    private interface SingleInputAction {
        void run(JTextField input, JTextArea output);
    }

    @FunctionalInterface
    private interface DoubleInputAction {
        void run(JTextField input1, JTextField input2, JTextArea output);
    }

    private JPanel createSingleInputPanel(
        String title,
        String number,
        String inputLabel,
        SingleInputAction action
    ) {
        JPanel panel = new JPanel(new BorderLayout(0, 14));
        panel.setBackground(BG_DARK);
        panel.setBorder(new EmptyBorder(28, 36, 28, 36));

        JTextField inputField = styledInput();
        JTextArea outputArea = styledOutput();

        JPanel top = new JPanel();
        top.setBackground(BG_DARK);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        top.add(pageHeader(title, number));
        top.add(Box.createVerticalStrut(20));
        top.add(inputRow(inputLabel, inputField));
        top.add(Box.createVerticalStrut(12));
        top.add(buttonRow(inputField, null, outputArea, action, null));
        top.add(Box.createVerticalStrut(16));

        panel.add(top, BorderLayout.NORTH);
        panel.add(styledScroll(outputArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createDoubleInputPanel(
        String title,
        String number,
        String label1,
        String label2,
        DoubleInputAction action
    ) {
        JPanel panel = new JPanel(new BorderLayout(0, 14));
        panel.setBackground(BG_DARK);
        panel.setBorder(new EmptyBorder(28, 36, 28, 36));

        JTextField input1 = styledInput();
        JTextField input2 = styledInput();
        JTextArea outputArea = styledOutput();

        JPanel top = new JPanel();
        top.setBackground(BG_DARK);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        top.add(pageHeader(title, number));
        top.add(Box.createVerticalStrut(20));
        top.add(inputRow(label1, input1));
        top.add(Box.createVerticalStrut(8));
        top.add(inputRow(label2, input2));
        top.add(Box.createVerticalStrut(12));
        top.add(buttonRow(input1, input2, outputArea, null, action));
        top.add(Box.createVerticalStrut(16));

        panel.add(top, BorderLayout.NORTH);
        panel.add(styledScroll(outputArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel pageHeader(String title, String number) {
        JPanel panel = new JPanel(new BorderLayout(12, 0));
        panel.setBackground(BG_DARK);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton back = new JButton("<- Menu");
        back.setFont(FONT_BACK);
        back.setForeground(TEXT_DIM);
        back.setBackground(BTN_RESET_BG);
        back.setBorder(new CompoundBorder(
            new LineBorder(BORDER_LINE, 1, true),
            new EmptyBorder(5, 12, 5, 12)
        ));
        back.setFocusPainted(false);
        back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        back.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                back.setForeground(TEXT_PRIMARY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                back.setForeground(TEXT_DIM);
            }
        });
        back.addActionListener(event -> cardLayout.show(cardPanel, "MENU"));

        JPanel titleWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        titleWrap.setBackground(BG_DARK);

        JLabel numberBadge = new JLabel(number);
        numberBadge.setFont(new Font("Monospaced", Font.BOLD, 11));
        numberBadge.setForeground(ACCENT);
        numberBadge.setBorder(new CompoundBorder(
            new LineBorder(ACCENT, 1, true),
            new EmptyBorder(2, 6, 2, 6)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        titleLabel.setForeground(TEXT_PRIMARY);

        titleWrap.add(numberBadge);
        titleWrap.add(titleLabel);

        panel.add(back, BorderLayout.WEST);
        panel.add(titleWrap, BorderLayout.CENTER);
        return panel;
    }

    private JPanel inputRow(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(10, 0));
        panel.setBackground(BG_DARK);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JLabel label = new JLabel(labelText);
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DIM);
        label.setPreferredSize(new Dimension(210, 28));

        panel.add(label, BorderLayout.WEST);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buttonRow(
        JTextField input1,
        JTextField input2,
        JTextArea output,
        SingleInputAction singleAction,
        DoubleInputAction doubleAction
    ) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panel.setBackground(BG_DARK);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton compute = accentButton("Compute");
        JButton reset = ghostButton("Reset");

        compute.addActionListener(event -> {
            showResult(output, "");
            if (singleAction != null) {
                singleAction.run(input1, output);
            } else if (doubleAction != null) {
                doubleAction.run(input1, input2, output);
            }
        });

        reset.addActionListener(event -> {
            input1.setText("");
            if (input2 != null) {
                input2.setText("");
            }
            showResult(output, "");
        });

        panel.add(compute);
        panel.add(reset);
        return panel;
    }

    private JButton accentButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics graphics) {
                Graphics2D graphics2D = (Graphics2D) graphics.create();
                graphics2D.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                if (getModel().isPressed()) {
                    graphics2D.setColor(ACCENT.darker());
                } else if (getModel().isRollover()) {
                    graphics2D.setColor(ACCENT_HOVER);
                } else {
                    graphics2D.setColor(ACCENT);
                }

                graphics2D.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                graphics2D.dispose();
                super.paintComponent(graphics);
            }
        };

        button.setFont(FONT_BTN);
        button.setForeground(Color.WHITE);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setBorder(new EmptyBorder(8, 22, 8, 22));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JButton ghostButton(String text) {
        JButton button = new JButton(text);
        button.setFont(FONT_BTN);
        button.setForeground(TEXT_DIM);
        button.setBackground(BTN_RESET_BG);
        button.setBorder(new CompoundBorder(
            new LineBorder(BORDER_LINE, 1, true),
            new EmptyBorder(7, 18, 7, 18)
        ));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setForeground(TEXT_PRIMARY);
                button.setBorder(new CompoundBorder(
                    new LineBorder(TEXT_DIM, 1, true),
                    new EmptyBorder(7, 18, 7, 18)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setForeground(TEXT_DIM);
                button.setBorder(new CompoundBorder(
                    new LineBorder(BORDER_LINE, 1, true),
                    new EmptyBorder(7, 18, 7, 18)
                ));
            }
        });
        return button;
    }

    private JTextField styledInput() {
        JTextField field = new JTextField();
        field.setFont(FONT_INPUT);
        field.setBackground(BG_INPUT);
        field.setForeground(TEXT_PRIMARY);
        field.setCaretColor(ACCENT_HOVER);
        field.setBorder(new CompoundBorder(
            new LineBorder(BORDER_LINE, 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        field.setPreferredSize(new Dimension(180, 32));

        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(new CompoundBorder(
                    new LineBorder(ACCENT, 1, true),
                    new EmptyBorder(6, 10, 6, 10)
                ));
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(new CompoundBorder(
                    new LineBorder(BORDER_LINE, 1, true),
                    new EmptyBorder(6, 10, 6, 10)
                ));
            }
        });

        return field;
    }

    private JTextArea styledOutput() {
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(FONT_OUTPUT);
        area.setBackground(BG_CARD);
        area.setForeground(TEXT_OUTPUT);
        area.setCaretColor(ACCENT_HOVER);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(new EmptyBorder(14, 16, 14, 16));
        return area;
    }

    private JScrollPane styledScroll(JTextArea area) {
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBorder(new LineBorder(BORDER_LINE, 1, true));
        scroll.setBackground(BG_CARD);
        scroll.getViewport().setBackground(BG_CARD);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        return scroll;
    }

    private int parseInt(JTextField field, JTextArea output) {
        if (isBlank(field)) {
            showError(output, Messages.EMPTY_INTEGER_INPUT);
            return Integer.MIN_VALUE;
        }
        try {
            return Integer.parseInt(field.getText().trim());
        } catch (NumberFormatException ex) {
            showError(output, Messages.INVALID_INTEGER_INPUT);
            return Integer.MIN_VALUE;
        }
    }

    private boolean isBlank(JTextField field) {
        return field.getText().trim().isEmpty();
    }

    private void showResult(JTextArea output, String message) {
        output.setForeground(TEXT_OUTPUT);
        output.setText(message);
    }

    private void showError(JTextArea output, String message) {
        output.setForeground(TEXT_ERROR);
        output.setText("Error: " + message);
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(main::new);
    }
}
