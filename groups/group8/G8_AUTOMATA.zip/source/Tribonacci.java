public final class Tribonacci {

    private Tribonacci() {
    }

    public static String validate(int n) {
        if (n <= 0) {
            return Messages.INVALID_NEGATIVE;
        }
        if (n <= 3) {
            return Messages.INPUT_GREATER_THAN_THREE;
        }
        return null;
    }

    public static String generate(int n) {
        long[] values = new long[n];
        values[0] = 0;
        if (n > 1) {
            values[1] = 0;
        }
        if (n > 2) {
            values[2] = 1;
        }

        for (int index = 3; index < n; index++) {
            values[index] = values[index - 1] + values[index - 2] + values[index - 3];
        }

        return formatSequence(values);
    }

    public static String buildResult(int n) {
        return "The Tribonacci numbers are: " + generate(n);
    }

    private static String formatSequence(long[] values) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < values.length; index++) {
            if (index > 0) {
                builder.append(", ");
            }
            builder.append(values[index]);
        }
        return builder.toString();
    }
}
